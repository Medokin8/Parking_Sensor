var files_dup =
[
    [ "drawableobject.hh", "drawableobject_8hh.html", "drawableobject_8hh" ],
    [ "gauge.hh", "gauge_8hh.html", "gauge_8hh" ],
    [ "image.hh", "image_8hh.html", "image_8hh" ],
    [ "mainwindow.hh", "mainwindow_8hh.html", "mainwindow_8hh" ],
    [ "roundedrectangle.hh", "roundedrectangle_8hh.html", "roundedrectangle_8hh" ],
    [ "zone.hh", "zone_8hh.html", "zone_8hh" ]
];