var mainwindow_8hh =
[
    [ "sensorData", "structsensor_data.html", "structsensor_data" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "sensorData", "mainwindow_8hh.html#aa07947c001d9a22be2a3b2c92d2ac77b", null ]
];