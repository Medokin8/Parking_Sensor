var searchData=
[
  ['readfromport_0',['readFromPort',['../class_main_window.html#a42f11195758f78967e670779c4535708',1,'MainWindow']]],
  ['roundedrectangle_1',['RoundedRectangle',['../class_rounded_rectangle.html#adc4221b1dde8faa8ce2066a8f6a78618',1,'RoundedRectangle']]]
];
