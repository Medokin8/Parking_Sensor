var searchData=
[
  ['zonecolor_0',['zoneColor',['../class_zone.html#aa91c27715d2cf879384b6989c00d92ab',1,'Zone']]]
];
