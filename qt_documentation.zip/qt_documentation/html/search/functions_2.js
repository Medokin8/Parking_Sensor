var searchData=
[
  ['image_0',['Image',['../class_image.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../class_image.html#a8f8633482a951bd0a9cba917a9af6169',1,'Image::Image(QPixmap image)'],['../class_image.html#ad371a92d8eec23560520a320582489e5',1,'Image::Image(float x, float y, float rot, float size, QPixmap image)']]]
];
