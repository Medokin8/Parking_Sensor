var searchData=
[
  ['on_5fpushbuttonconnect_5fclicked_0',['on_pushButtonConnect_clicked',['../class_main_window.html#a74bf7ec51582db3d2d98265b66afc0cc',1,'MainWindow']]],
  ['on_5fpushbuttondisconnect_5fclicked_1',['on_pushButtonDisconnect_clicked',['../class_main_window.html#a38e5a7fd929962f8ff7591a3d688f9c3',1,'MainWindow']]],
  ['on_5fpushbuttonsearch_5fclicked_2',['on_pushButtonSearch_clicked',['../class_main_window.html#a5dd6fd2201adc933d4fe8d053865710f',1,'MainWindow']]]
];
