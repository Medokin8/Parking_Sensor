var searchData=
[
  ['zone_0',['Zone',['../class_zone.html#a37c9721c0d592a7a231f4e6dbae93277',1,'Zone::Zone()'],['../class_zone.html#a271c09ea7dfa5d6788a239e45b345747',1,'Zone::Zone(float x, float y, float r, float s)']]]
];
