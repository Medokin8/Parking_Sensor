var searchData=
[
  ['sensordata_0',['sensorData',['../mainwindow_8hh.html#aa07947c001d9a22be2a3b2c92d2ac77b',1,'mainwindow.hh']]]
];
