var searchData=
[
  ['pixmap_0',['pixmap',['../class_image.html#a7f3b56d61ff38b6bd7d6dc042cfbc575',1,'Image']]],
  ['pointpen_1',['pointPen',['../class_main_window.html#aa4c58ef8cf8b3fa1dcbac71b7ceda53c',1,'MainWindow']]],
  ['positionx_2',['positionX',['../class_drawable_object.html#ab2e329d31b6b80ed5a4e2c535af08055',1,'DrawableObject']]],
  ['positiony_3',['positionY',['../class_drawable_object.html#a4d7ba1db7e5ad31e04f37c9a62925918',1,'DrawableObject']]]
];
