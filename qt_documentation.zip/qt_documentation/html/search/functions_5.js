var searchData=
[
  ['paintevent_0',['paintEvent',['../class_main_window.html#abf05d580e91f725777cdb6a5eb0bf08c',1,'MainWindow']]],
  ['parsedmeasurementready_1',['parsedMeasurementReady',['../class_main_window.html#a5169de450534f844cd53f4050cb19d79',1,'MainWindow']]],
  ['process_5fline_2',['process_line',['../class_main_window.html#a8f0aee26668224f86a8a1a55fc1e94d1',1,'MainWindow']]]
];
