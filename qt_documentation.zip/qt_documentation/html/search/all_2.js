var searchData=
[
  ['endbottom_0',['endBottom',['../class_zone.html#a357f20a2d85506cdabcaf435b11da8c0',1,'Zone']]],
  ['endtop_1',['endTop',['../class_zone.html#a2dd14be38b07a41540d77c794bd8b54b',1,'Zone']]]
];
