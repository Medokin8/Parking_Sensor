var class_image =
[
    [ "Image", "class_image.html#a58edd1c45b4faeb5f789b0d036d02313", null ],
    [ "Image", "class_image.html#a8f8633482a951bd0a9cba917a9af6169", null ],
    [ "Image", "class_image.html#ad371a92d8eec23560520a320582489e5", null ],
    [ "~Image", "class_image.html#a0294f63700543e11c0f0da85601c7ae5", null ],
    [ "getPixmap", "class_image.html#a02e502050e1094ae6c4525094467bce9", null ],
    [ "setPixmap", "class_image.html#a6b73ea8c1e9d94bba052b78385dc741b", null ],
    [ "pixmap", "class_image.html#a7f3b56d61ff38b6bd7d6dc042cfbc575", null ]
];