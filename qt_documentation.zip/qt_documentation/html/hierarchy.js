var hierarchy =
[
    [ "DrawableObject", "class_drawable_object.html", [
      [ "Gauge", "class_gauge.html", null ],
      [ "Image", "class_image.html", null ],
      [ "RoundedRectangle", "class_rounded_rectangle.html", null ],
      [ "Zone", "class_zone.html", null ]
    ] ],
    [ "QDialog", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "sensorData", "structsensor_data.html", null ]
];