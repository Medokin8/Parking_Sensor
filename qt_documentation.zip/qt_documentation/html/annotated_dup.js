var annotated_dup =
[
    [ "DrawableObject", "class_drawable_object.html", "class_drawable_object" ],
    [ "Gauge", "class_gauge.html", "class_gauge" ],
    [ "Image", "class_image.html", "class_image" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "RoundedRectangle", "class_rounded_rectangle.html", "class_rounded_rectangle" ],
    [ "sensorData", "structsensor_data.html", "structsensor_data" ],
    [ "Zone", "class_zone.html", "class_zone" ]
];